#!/bin/bash

a="1111"
b="bbbb"
c=$@
d=$*
e=$#

echo "a=type($a)"
echo "b=type($b)"
echo "c=type($c)"
echo "d=type($d)"
echo "e=type($e)"
echo "f=$0"
echo "$!"
echo $$
ls
echo $_
echo $n
