# TencentCloud VPC Backend for Flannel

There are only two differences between the usage method and Alibaba Cloud:
1. Tencent Cloud needs to create a routing table, while Alibaba Cloud creates a switch
2. In network/config, backend-type is "tencent-vpc"


