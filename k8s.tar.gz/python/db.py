# -*-coding: utf-8 -*-

import  sys
import  os
import  random
import  json
import  logging
import  datetime
import  requests
import  redis
import  pymysql
import  pymssql


print("hello world")

def connect_mysql():  
    db_config = {  
        'host': '172.39.9.10',
        'user': 'root',
        'password': '111111',
        'database': 'ucen_portal',
        'charset': 'utf8mb4', 
        'cursorclass': pymysql.cursors.DictCursor
    }  
  
    connection = pymysql.connect(**db_config)  
  
    try:  
        # 创建一个游标对象  
        with connection.cursor() as cursor:  
            sql = "SELECT * FROM platform_app"  
            cursor.execute(sql)  
            results = cursor.fetchall()  
            for row in results:  
#                print(row)
                print json.dumps(row['name'],encoding='UTF-8', ensure_ascii=False)
    finally:  
        connection.close()
  
def connect_redis():  
    """连接到Redis服务器"""  
    try:  
        r = redis.Redis(host='172.39.9.10', port=6379, db=0, password='123456')
#        r = redis.Redis(host='172.39.8.32', port=6379, db=0, password='12345678@cdhr')
        keys = r.keys('*')  
  
        for key in keys:  
            data = json.loads(r.get(key))
            print(type(data))
            redis_json = json.dumps(data, ensure_ascii=False, indent=4)
            print(redis_json)
#            print(r.get(key))
    except redis.RedisError as e:  
        print("连接Redis失败: {e}")  

aaa=connect_mysql()
print(1111111111111111111111111)
#bbb=connect_redis()

os.system("ls")
